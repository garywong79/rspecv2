require "rspec"

require_relative "list"

describe List do
  # Your specs here
end