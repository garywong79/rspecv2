require "rspec"

require_relative "account"

describe Account do
  describe "#initialize" do

  end

  describe "#transactions" do

  end

  describe "#balance" do

  end

  describe "#account_number" do

  end

  describe "deposit!" do

  end

  describe "#withdraw!" do

  end
end