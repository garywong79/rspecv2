# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DbcRspecRails::Application.config.secret_token = '6d6e967c275688e72d4a7520be07ad68d0307948574f4505da4958dc23cab8ec1fb07e6fa57a641f07e24277bd8f6db7dfa6f3bb442955b8d33b9ef95edda7a4'
